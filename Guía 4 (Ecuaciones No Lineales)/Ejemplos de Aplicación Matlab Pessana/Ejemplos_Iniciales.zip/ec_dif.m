%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% M�todos Num�ricos
% Introducci�n a la programaci�n
% Ecuaci�n diferencial para resolver la salida
% del sistema masa-resorte del ejemplo4.m
% ante la presencia de una fuerza sinusoidal
%%% Dr. Ing. Franco Pessana
%%% FICEN
%%% Universidad Favaloro
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function vp=ec_dif(t,v)

Ft=30*sin(2*pi*5000*t);
D=1000;
M=1;
g=9.81;
vp=(Ft+M*g)/M - D*v/M;